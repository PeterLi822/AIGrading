import json
import boto3
import re
import urllib.parse
from openai import OpenAI
from docx import Document

# Initialize clients
s3_client = boto3.client('s3')

def read_docx(file_path):
    doc = Document(file_path)
    full_text = []
    for para in doc.paragraphs:
        full_text.append(para.text)
    return '\n'.join(full_text)

def save_to_docx(file_path, content):
    doc = Document()
    for line in content.split('\n'):
        doc.add_paragraph(line)
    doc.save(file_path)

def extract_grade_and_feedback(graded_result):
    # Define regex patterns to extract grade and feedback
    grade_pattern = re.compile(r"Overall Grade:\s*(\d+%)")
    feedback_pattern = re.compile(r"Feedback:\s*(.*?)(Error:|\Z)", re.DOTALL)
    
    grade_match = grade_pattern.search(graded_result)
    feedback_match = feedback_pattern.search(graded_result)
    
    if not grade_match or not feedback_match:
        raise ValueError("Failed to extract grade and feedback from the result")

    return grade_match.group(1), feedback_match.group(1).strip()

def lambda_handler(event, context):
    try:
        # Set the API key directly here for testing purposes
        client = OpenAI(api_key="sk-None-PgUfEJFVqwaUuob3FlWjT3BlbkFJNEviPjoeKrNWAb6kwVii")

        # Extract bucket name and object key from the event
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        assignment_key = event['Records'][0]['s3']['object']['key']
        
        # URL decode the S3 object key
        assignment_key = urllib.parse.unquote_plus(assignment_key)
     
        # Filter out non-docx files
        if not assignment_key.endswith('.docx'):
            print(f"Skipping non-docx file: {assignment_key}")
            return {
                'statusCode': 200,
                'body': json.dumps('Skipped non-docx file')
            }

        # Define the requirements document key (assuming it's always the same file in the bucket)
        requirements_key = 'requirements.docx'

        # Log bucket name and object keys
        print(f"Received event: {json.dumps(event, indent=2)}")
        print(f"Bucket: {bucket_name}, Assignment Key: {assignment_key}, Requirements Key: {requirements_key}")
     
        # Download the assignment file from S3
        assignment_path = f'/tmp/{assignment_key.split("/")[-1]}'
        print(f"Downloading assignment file from S3: {assignment_path}")
        s3_client.download_file(bucket_name, assignment_key, assignment_path)
        
        # Get metadata of the assignment file
        assignment_metadata = s3_client.head_object(Bucket=bucket_name, Key=assignment_key).get('Metadata', {})

        # Read the assignment content
        assignment_content = read_docx(assignment_path)
        print(f"Assignment content: {assignment_content[:100]}...")  # Log first 100 chars

        # Download the requirements document from S3
        requirements_path = f'/tmp/{requirements_key.split("/")[-1]}'
        print(f"Downloading requirements document from S3: {requirements_path}")
        s3_client.download_file(bucket_name, requirements_key, requirements_path)
     
        # Read the requirements content
        assignment_requirements = read_docx(requirements_path)
        print(f"Assignment requirements: {assignment_requirements}")
     
        # Construct the prompt with assignment requirements
        prompt = (
            f"Grade the following assignment based on these requirements:\n\n{assignment_requirements}\n\n"
            f"Assignment:\n\n{assignment_content}\n\n"
        )
     
        # Call OpenAI API to grade the assignment
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a grading assistant."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1500
        )
     
        graded_result = response.choices[0].message.content.strip()
        print(f"Graded result: {graded_result}")
        
        # Extract grade and feedback from the result
        try:
            grade, feedback = extract_grade_and_feedback(graded_result)
        except Exception as e:
            print(f"Error extracting grade and feedback: {str(e)}")
            print(f"Full graded result: {graded_result}")
            raise e
        
        # Update metadata with the grade
        assignment_metadata['OverallGrade'] = grade

        # Append grade and feedback to assignment content
        updated_assignment_content = assignment_content + f"\n\nOverall Grade: {grade}\n\nAdditional Feedback:\n" + feedback

        # Save the updated content to a new docx file
        updated_assignment_path = f'/tmp/{assignment_key.split("/")[-1]}'
        save_to_docx(updated_assignment_path, updated_assignment_content)
     
        # Define the output bucket name (where graded results will be saved)
        output_bucket_name = 'gpt-review-results'
     
        # Upload the updated assignment file with feedback appended and updated metadata to the output bucket
        print(f"Saving updated assignment with feedback and metadata to S3: {output_bucket_name}/{assignment_key}")
        s3_client.upload_file(updated_assignment_path, output_bucket_name, assignment_key, ExtraArgs={"Metadata": assignment_metadata})
     
        return {
            'statusCode': 200,
            'body': json.dumps('Assignment graded successfully')
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error processing assignment: {str(e)}")
        }
